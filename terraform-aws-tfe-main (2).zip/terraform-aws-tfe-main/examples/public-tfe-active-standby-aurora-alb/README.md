# Overview  

This module showcases an example of utilizing the root module of this repository to build out the following high level components for a TFE deployment inside of AWS in **multiple regions** with an active/standby configuration:  

**Root Module Primary and Secondary Regions**  
-  VPC with Public and Private access  
-  VPC Endpoints  
-  Secrets Manager Secrets  
-  S3 buckets  
-  S3 Cross Region Replication  
-  Global Aurora PostgreSQL cluster  
-  Application Load Balancer, Listeners, and Target Groups  
-  ACM Certificate for Load Balancer  
-  Route 53 entries (Regional record and Failover record)  
-  KMS Encryption Keys  
-  Log Groups for TFE  
-  TFE KeyPair for TFE  

**TFE Module Primary and Secondary Regions**  
-  TFE EC2 AutoScaling Group (in secondary region, the ASG replica count is set to 0)  
-  TFE EC2 Launch Template  

## Failover Testing steps

**Note**
This assumes you have already deployed the example. We are mimicing a controlled failover as a part of the first portion and a DB failing over without TFE being aware in the second half.

1. Change the `asg_instance_count = 1` to `0` for the `active_tfe` module call.
2. `terraform apply`
3. Login to AWS and failover the aurora cluster to the secondary region.
4. Change `asg_instance_count = 0` to `1` for the `standby_tfe` module call.
5. `terrform apply`
6. Retry the tfe url after about 7 minutes and make sure it works. Might need to use a different browser or incognito.
7. Login to TFE and add a workspace or project. This is so we can show the configuration changes are present when we fail back.
8. Login to AWS and failover the database cluster to mimic it dropping.
9. Change `asg_instance_count = 0` to `1` for `active_tfe` and `asg_instance_count = 1` to `0` for the `standby_tfe` module call.
10. `terraform apply`
11. Retry the tfe url after about 7 minutes once the run is complete. Ensure that the changes you made from the second site is present when you failed back.

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.4.0 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >=4.55.0 |

## Providers

No providers.

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_active_tfe"></a> [active\_tfe](#module\_active\_tfe) | ../../ | n/a |
| <a name="module_standby_tfe"></a> [standby\_tfe](#module\_standby\_tfe) | ../../ | n/a |

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_active_license_arn"></a> [active\_license\_arn](#input\_active\_license\_arn) | ARN of the TFE license that is stored within secrets manager. | `string` | n/a | yes |
| <a name="input_active_private_subnets"></a> [active\_private\_subnets](#input\_active\_private\_subnets) | List of subnet IDs to use for the EC2 instance. Private subnets is the best practice. | `list(string)` | n/a | yes |
| <a name="input_active_route53_failover_fqdn"></a> [active\_route53\_failover\_fqdn](#input\_active\_route53\_failover\_fqdn) | Hostname/FQDN of TFE instance. This name should resolve to the load balancer DNS name and will be how users and systems access TFE. | `string` | n/a | yes |
| <a name="input_active_tfe_asg_hook_value"></a> [active\_tfe\_asg\_hook\_value](#input\_active\_tfe\_asg\_hook\_value) | Value for the tag that is associated with the launch template. This is used for the lifecycle hook checkin. | `string` | n/a | yes |
| <a name="input_active_tfe_console_password_arn"></a> [active\_tfe\_console\_password\_arn](#input\_active\_tfe\_console\_password\_arn) | Password to unlock TFE Admin Console accessible via port 8800. | `string` | n/a | yes |
| <a name="input_active_tfe_enc_password_arn"></a> [active\_tfe\_enc\_password\_arn](#input\_active\_tfe\_enc\_password\_arn) | Password to protect unseal key and root token of TFE embedded Vault. | `string` | n/a | yes |
| <a name="input_active_vpc_id"></a> [active\_vpc\_id](#input\_active\_vpc\_id) | VPC ID that TFE will be deployed into. | `string` | n/a | yes |
| <a name="input_friendly_name_prefix"></a> [friendly\_name\_prefix](#input\_friendly\_name\_prefix) | Friendly name prefix used for tagging and naming AWS resources. | `string` | n/a | yes |
| <a name="input_standby_license_arn"></a> [standby\_license\_arn](#input\_standby\_license\_arn) | ARN of the TFE license that is stored within secrets manager. | `string` | n/a | yes |
| <a name="input_standby_private_subnets"></a> [standby\_private\_subnets](#input\_standby\_private\_subnets) | List of subnet IDs to use for the EC2 instance. Private subnets is the best practice. | `list(string)` | n/a | yes |
| <a name="input_standby_route53_failover_fqdn"></a> [standby\_route53\_failover\_fqdn](#input\_standby\_route53\_failover\_fqdn) | Hostname/FQDN of TFE instance. This name should resolve to the load balancer DNS name and will be how users and systems access TFE. | `string` | n/a | yes |
| <a name="input_standby_tfe_asg_hook_value"></a> [standby\_tfe\_asg\_hook\_value](#input\_standby\_tfe\_asg\_hook\_value) | Value for the tag that is associated with the launch template. This is used for the lifecycle hook checkin. | `string` | n/a | yes |
| <a name="input_standby_tfe_console_password_arn"></a> [standby\_tfe\_console\_password\_arn](#input\_standby\_tfe\_console\_password\_arn) | Password to unlock TFE Admin Console accessible via port 8800. | `string` | n/a | yes |
| <a name="input_standby_tfe_enc_password_arn"></a> [standby\_tfe\_enc\_password\_arn](#input\_standby\_tfe\_enc\_password\_arn) | Password to protect unseal key and root token of TFE embedded Vault. | `string` | n/a | yes |
| <a name="input_standby_vpc_id"></a> [standby\_vpc\_id](#input\_standby\_vpc\_id) | VPC ID that TFE will be deployed into. | `string` | n/a | yes |
| <a name="input_active_common_tags"></a> [active\_common\_tags](#input\_active\_common\_tags) | Map of common tags for all taggable AWS resources. | `map(string)` | `{}` | no |
| <a name="input_active_db_cluster_endpoint"></a> [active\_db\_cluster\_endpoint](#input\_active\_db\_cluster\_endpoint) | Writer endpoint for the cluster | `string` | `""` | no |
| <a name="input_active_kms_key_alias_arn"></a> [active\_kms\_key\_alias\_arn](#input\_active\_kms\_key\_alias\_arn) | ARN of KMS key alias or key to encrypt TFE RDS, S3, EBS, and Redis resources. | `string` | `""` | no |
| <a name="input_active_lb_security_group_id"></a> [active\_lb\_security\_group\_id](#input\_active\_lb\_security\_group\_id) | Security Group ID for the Load Balancer | `string` | `""` | no |
| <a name="input_active_load_balancer_type"></a> [active\_load\_balancer\_type](#input\_active\_load\_balancer\_type) | String indicating whether the load balancer deployed is an Application Load Balancer (alb) or Network Load Balancer (nlb). | `string` | `""` | no |
| <a name="input_active_region"></a> [active\_region](#input\_active\_region) | AWS Primary Region | `string` | `"us-east-2"` | no |
| <a name="input_active_s3_log_bucket_name"></a> [active\_s3\_log\_bucket\_name](#input\_active\_s3\_log\_bucket\_name) | Name of bucket to configure as log forwarding destination. `log_forwarding_enabled` must also be `true`. | `string` | `""` | no |
| <a name="input_active_s3_tfe_app_bucket_name"></a> [active\_s3\_tfe\_app\_bucket\_name](#input\_active\_s3\_tfe\_app\_bucket\_name) | Name of S3 S3 Terraform Enterprise Object Store bucket. | `string` | `""` | no |
| <a name="input_active_tfe_cert_secret_arn"></a> [active\_tfe\_cert\_secret\_arn](#input\_active\_tfe\_cert\_secret\_arn) | ARN of AWS Secrets Manager secret for TFE server certificate in PEM format. Required if `tls_bootstrap_type` is `server-path`; otherwise ignored. | `string` | `""` | no |
| <a name="input_active_tfe_iam_role_name"></a> [active\_tfe\_iam\_role\_name](#input\_active\_tfe\_iam\_role\_name) | Name of AWS IAM Instance Profile for TFE EC2 Instance | `string` | `""` | no |
| <a name="input_active_tfe_keypair_name"></a> [active\_tfe\_keypair\_name](#input\_active\_tfe\_keypair\_name) | Public key material for TFE SSH Key Pair. | `string` | `null` | no |
| <a name="input_active_tfe_log_group_name"></a> [active\_tfe\_log\_group\_name](#input\_active\_tfe\_log\_group\_name) | Name of CloudWatch Log Group to configure as log forwarding destination. `log_forwarding_enabled` must also be `true`. | `string` | `""` | no |
| <a name="input_active_tfe_privkey_secret_arn"></a> [active\_tfe\_privkey\_secret\_arn](#input\_active\_tfe\_privkey\_secret\_arn) | ARN of AWS Secrets Manager secret for TFE private key in PEM format and base64 encoded. Required if `tls_bootstrap_type` is `server-path`; otherwise ignored. | `string` | `""` | no |
| <a name="input_active_tfe_target_group_arns"></a> [active\_tfe\_target\_group\_arns](#input\_active\_tfe\_target\_group\_arns) | List of Target Group ARNs associated with the TFE Load Balancer | `list(any)` | `[]` | no |
| <a name="input_db_database_name"></a> [db\_database\_name](#input\_db\_database\_name) | Name of database that will be created (if specified) or consumed by TFE. | `string` | `"tfe"` | no |
| <a name="input_db_password"></a> [db\_password](#input\_db\_password) | Password for the DB user. | `string` | `null` | no |
| <a name="input_db_username"></a> [db\_username](#input\_db\_username) | Username for the DB user. | `string` | `"tfe"` | no |
| <a name="input_enable_active_active"></a> [enable\_active\_active](#input\_enable\_active\_active) | Boolean to enable TFE Active/Active and in turn deploy Redis cluster. | `bool` | `false` | no |
| <a name="input_standby_common_tags"></a> [standby\_common\_tags](#input\_standby\_common\_tags) | Map of common tags for all taggable AWS resources. | `map(string)` | `{}` | no |
| <a name="input_standby_db_cluster_endpoint"></a> [standby\_db\_cluster\_endpoint](#input\_standby\_db\_cluster\_endpoint) | Writer endpoint for the cluster | `string` | `""` | no |
| <a name="input_standby_kms_key_alias_arn"></a> [standby\_kms\_key\_alias\_arn](#input\_standby\_kms\_key\_alias\_arn) | ARN of KMS key alias or key to encrypt TFE RDS, S3, EBS, and Redis resources. | `string` | `""` | no |
| <a name="input_standby_lb_security_group_id"></a> [standby\_lb\_security\_group\_id](#input\_standby\_lb\_security\_group\_id) | Security Group ID for the Load Balancer | `string` | `""` | no |
| <a name="input_standby_load_balancer_type"></a> [standby\_load\_balancer\_type](#input\_standby\_load\_balancer\_type) | String indicating whether the load balancer deployed is an Application Load Balancer (alb) or Network Load Balancer (nlb). | `string` | `""` | no |
| <a name="input_standby_region"></a> [standby\_region](#input\_standby\_region) | AWS Primary Region | `string` | `"us-west-2"` | no |
| <a name="input_standby_s3_log_bucket_name"></a> [standby\_s3\_log\_bucket\_name](#input\_standby\_s3\_log\_bucket\_name) | Name of bucket to configure as log forwarding destination. `log_forwarding_enabled` must also be `true`. | `string` | `""` | no |
| <a name="input_standby_s3_tfe_app_bucket_name"></a> [standby\_s3\_tfe\_app\_bucket\_name](#input\_standby\_s3\_tfe\_app\_bucket\_name) | Name of S3 S3 Terraform Enterprise Object Store bucket. | `string` | `""` | no |
| <a name="input_standby_tfe_cert_secret_arn"></a> [standby\_tfe\_cert\_secret\_arn](#input\_standby\_tfe\_cert\_secret\_arn) | ARN of AWS Secrets Manager secret for TFE server certificate in PEM format. Required if `tls_bootstrap_type` is `server-path`; otherwise ignored. | `string` | `""` | no |
| <a name="input_standby_tfe_iam_role_name"></a> [standby\_tfe\_iam\_role\_name](#input\_standby\_tfe\_iam\_role\_name) | Name of AWS IAM Instance Profile for TFE EC2 Instance | `string` | `""` | no |
| <a name="input_standby_tfe_keypair_name"></a> [standby\_tfe\_keypair\_name](#input\_standby\_tfe\_keypair\_name) | Public key material for TFE SSH Key Pair. | `string` | `null` | no |
| <a name="input_standby_tfe_log_group_name"></a> [standby\_tfe\_log\_group\_name](#input\_standby\_tfe\_log\_group\_name) | Name of CloudWatch Log Group to configure as log forwarding destination. `log_forwarding_enabled` must also be `true`. | `string` | `""` | no |
| <a name="input_standby_tfe_privkey_secret_arn"></a> [standby\_tfe\_privkey\_secret\_arn](#input\_standby\_tfe\_privkey\_secret\_arn) | ARN of AWS Secrets Manager secret for TFE private key in PEM format and base64 encoded. Required if `tls_bootstrap_type` is `server-path`; otherwise ignored. | `string` | `""` | no |
| <a name="input_standby_tfe_target_group_arns"></a> [standby\_tfe\_target\_group\_arns](#input\_standby\_tfe\_target\_group\_arns) | List of Target Group ARNs associated with the TFE Load Balancer | `list(any)` | `[]` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_active_asg_healthcheck_type"></a> [active\_asg\_healthcheck\_type](#output\_active\_asg\_healthcheck\_type) | Type of health check that is associated with the AWS autoscaling group. |
| <a name="output_active_asg_lifecycle_hook_name"></a> [active\_asg\_lifecycle\_hook\_name](#output\_active\_asg\_lifecycle\_hook\_name) | Name of the AWS autoscaling group lifecycle hook that has been created |
| <a name="output_active_asg_name"></a> [active\_asg\_name](#output\_active\_asg\_name) | Name of the AWS autoscaling group that was created during the run. |
| <a name="output_active_asg_target_group_arns"></a> [active\_asg\_target\_group\_arns](#output\_active\_asg\_target\_group\_arns) | List of the target group ARNs that are used for the AWS autoscaling group |
| <a name="output_active_launch_template_name"></a> [active\_launch\_template\_name](#output\_active\_launch\_template\_name) | Name of the AWS launch template that was created during the run |
| <a name="output_active_security_group_ids"></a> [active\_security\_group\_ids](#output\_active\_security\_group\_ids) | List of security groups that have been created during the run. |
| <a name="output_active_tfe_admin_console_url"></a> [active\_tfe\_admin\_console\_url](#output\_active\_tfe\_admin\_console\_url) | URL of TFE (Replicated) Admin Console based on `route53_failover_fqdn` input. |
| <a name="output_active_tfe_url"></a> [active\_tfe\_url](#output\_active\_tfe\_url) | URL of TFE application based on `route53_failover_fqdn` input. |
| <a name="output_active_user_data_script"></a> [active\_user\_data\_script](#output\_active\_user\_data\_script) | base64 decoded user data script that is attached to the launch template |
| <a name="output_standby_asg_healthcheck_type"></a> [standby\_asg\_healthcheck\_type](#output\_standby\_asg\_healthcheck\_type) | Type of health check that is associated with the AWS autoscaling group. |
| <a name="output_standby_asg_lifecycle_hook_name"></a> [standby\_asg\_lifecycle\_hook\_name](#output\_standby\_asg\_lifecycle\_hook\_name) | Name of the AWS autoscaling group lifecycle hook that has been created |
| <a name="output_standby_asg_name"></a> [standby\_asg\_name](#output\_standby\_asg\_name) | Name of the AWS autoscaling group that was created during the run. |
| <a name="output_standby_asg_target_group_arns"></a> [standby\_asg\_target\_group\_arns](#output\_standby\_asg\_target\_group\_arns) | List of the target group ARNs that are used for the AWS autoscaling group |
| <a name="output_standby_launch_template_name"></a> [standby\_launch\_template\_name](#output\_standby\_launch\_template\_name) | Name of the AWS launch template that was created during the run |
| <a name="output_standby_security_group_ids"></a> [standby\_security\_group\_ids](#output\_standby\_security\_group\_ids) | List of security groups that have been created during the run. |
| <a name="output_standby_tfe_admin_console_url"></a> [standby\_tfe\_admin\_console\_url](#output\_standby\_tfe\_admin\_console\_url) | URL of TFE (Replicated) Admin Console based on `route53_failover_fqdn` input. |
| <a name="output_standby_tfe_url"></a> [standby\_tfe\_url](#output\_standby\_tfe\_url) | URL of TFE application based on `route53_failover_fqdn` input. |
| <a name="output_standby_user_data_script"></a> [standby\_user\_data\_script](#output\_standby\_user\_data\_script) | base64 decoded user data script that is attached to the launch template |
<!-- END_TF_DOCS -->
