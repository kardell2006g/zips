# Overview  

This module showcases an example of utilizing the root module of this repository to build out the following high level components for a TFE **single-site** deployment inside of AWS in a **specific region**:  

**Root Module**  
-  VPC with Public and Private access  
-  VPC Endpoints  
-  Secrets Manager Secrets  
-  S3 buckets  
-  Regional Aurora PostgreSQL cluster  
-  Application Load Balancer, Listeners, and Target Groups  
-  Route 53 entries  
-  ACM Certificate for Load Balancer  
-  KMS Encryption Keys  
-  Log Groups for TFE  
-  TFE KeyPair for TFE  

**TFE Module**  
-  TFE EC2 AutoScaling Group  
-  TFE EC2 Launch Template  


<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.4.0 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >=4.55.0 |

## Providers

No providers.

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_tfe"></a> [tfe](#module\_tfe) | ../../ | n/a |

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_friendly_name_prefix"></a> [friendly\_name\_prefix](#input\_friendly\_name\_prefix) | Friendly name prefix used for tagging and naming AWS resources. | `string` | n/a | yes |
| <a name="input_license_arn"></a> [license\_arn](#input\_license\_arn) | ARN of the TFE license that is stored within secrets manager. | `string` | n/a | yes |
| <a name="input_private_subnets"></a> [private\_subnets](#input\_private\_subnets) | List of subnet IDs to use for the EC2 instance. Private subnets is the best practice. | `list(string)` | n/a | yes |
| <a name="input_route53_failover_fqdn"></a> [route53\_failover\_fqdn](#input\_route53\_failover\_fqdn) | Hostname/FQDN of TFE instance. This name should resolve to the load balancer DNS name and will be how users and systems access TFE. | `string` | n/a | yes |
| <a name="input_tfe_asg_hook_value"></a> [tfe\_asg\_hook\_value](#input\_tfe\_asg\_hook\_value) | Value for the tag that is associated with the launch template. This is used for the lifecycle hook checkin. | `string` | n/a | yes |
| <a name="input_tfe_console_password_arn"></a> [tfe\_console\_password\_arn](#input\_tfe\_console\_password\_arn) | Password to unlock TFE Admin Console accessible via port 8800. | `string` | n/a | yes |
| <a name="input_tfe_enc_password_arn"></a> [tfe\_enc\_password\_arn](#input\_tfe\_enc\_password\_arn) | Password to protect unseal key and root token of TFE embedded Vault. | `string` | n/a | yes |
| <a name="input_vpc_id"></a> [vpc\_id](#input\_vpc\_id) | VPC ID that TFE will be deployed into. | `string` | n/a | yes |
| <a name="input_common_tags"></a> [common\_tags](#input\_common\_tags) | Map of common tags for all taggable AWS resources. | `map(string)` | `{}` | no |
| <a name="input_db_cluster_endpoint"></a> [db\_cluster\_endpoint](#input\_db\_cluster\_endpoint) | Writer endpoint for the cluster | `string` | `""` | no |
| <a name="input_db_database_name"></a> [db\_database\_name](#input\_db\_database\_name) | Name of database that will be created (if specified) or consumed by TFE. | `string` | `"tfe"` | no |
| <a name="input_db_password"></a> [db\_password](#input\_db\_password) | Password for the DB user. | `string` | `null` | no |
| <a name="input_db_username"></a> [db\_username](#input\_db\_username) | Username for the DB user. | `string` | `"tfe"` | no |
| <a name="input_enable_active_active"></a> [enable\_active\_active](#input\_enable\_active\_active) | Boolean to enable TFE Active/Active and in turn deploy Redis cluster. | `bool` | `false` | no |
| <a name="input_kms_key_alias_arn"></a> [kms\_key\_alias\_arn](#input\_kms\_key\_alias\_arn) | ARN of KMS key alias or key to encrypt TFE RDS, S3, EBS, and Redis resources. | `string` | `""` | no |
| <a name="input_lb_security_group_id"></a> [lb\_security\_group\_id](#input\_lb\_security\_group\_id) | Security Group ID for the Load Balancer | `string` | `""` | no |
| <a name="input_load_balancer_type"></a> [load\_balancer\_type](#input\_load\_balancer\_type) | String indicating whether the load balancer deployed is an Application Load Balancer (alb) or Network Load Balancer (nlb). | `string` | `""` | no |
| <a name="input_region"></a> [region](#input\_region) | AWS Region | `string` | `"us-east-2"` | no |
| <a name="input_s3_log_bucket_name"></a> [s3\_log\_bucket\_name](#input\_s3\_log\_bucket\_name) | Name of bucket to configure as log forwarding destination. `log_forwarding_enabled` must also be `true`. | `string` | `""` | no |
| <a name="input_s3_tfe_app_bucket_name"></a> [s3\_tfe\_app\_bucket\_name](#input\_s3\_tfe\_app\_bucket\_name) | Name of S3 S3 Terraform Enterprise Object Store bucket. | `string` | `""` | no |
| <a name="input_tfe_cert_secret_arn"></a> [tfe\_cert\_secret\_arn](#input\_tfe\_cert\_secret\_arn) | ARN of AWS Secrets Manager secret for TFE server certificate in PEM format. Required if `tls_bootstrap_type` is `server-path`; otherwise ignored. | `string` | `""` | no |
| <a name="input_tfe_iam_role_name"></a> [tfe\_iam\_role\_name](#input\_tfe\_iam\_role\_name) | Name of AWS IAM Instance Profile for TFE EC2 Instance | `string` | `""` | no |
| <a name="input_tfe_keypair_name"></a> [tfe\_keypair\_name](#input\_tfe\_keypair\_name) | Public key material for TFE SSH Key Pair. | `string` | `null` | no |
| <a name="input_tfe_log_group_name"></a> [tfe\_log\_group\_name](#input\_tfe\_log\_group\_name) | Name of CloudWatch Log Group to configure as log forwarding destination. `log_forwarding_enabled` must also be `true`. | `string` | `""` | no |
| <a name="input_tfe_privkey_secret_arn"></a> [tfe\_privkey\_secret\_arn](#input\_tfe\_privkey\_secret\_arn) | ARN of AWS Secrets Manager secret for TFE private key in PEM format and base64 encoded. Required if `tls_bootstrap_type` is `server-path`; otherwise ignored. | `string` | `""` | no |
| <a name="input_tfe_target_group_arns"></a> [tfe\_target\_group\_arns](#input\_tfe\_target\_group\_arns) | List of Target Group ARNs associated with the TFE Load Balancer | `list(any)` | `[]` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_asg_healthcheck_type"></a> [asg\_healthcheck\_type](#output\_asg\_healthcheck\_type) | Type of health check that is associated with the AWS autoscaling group. |
| <a name="output_asg_lifecycle_hook_name"></a> [asg\_lifecycle\_hook\_name](#output\_asg\_lifecycle\_hook\_name) | Name of the AWS autoscaling group lifecycle hook that has been created |
| <a name="output_asg_name"></a> [asg\_name](#output\_asg\_name) | Name of the AWS autoscaling group that was created during the run. |
| <a name="output_asg_target_group_arns"></a> [asg\_target\_group\_arns](#output\_asg\_target\_group\_arns) | List of the target group ARNs that are used for the AWS autoscaling group |
| <a name="output_launch_template_name"></a> [launch\_template\_name](#output\_launch\_template\_name) | Name of the AWS launch template that was created during the run |
| <a name="output_security_group_ids"></a> [security\_group\_ids](#output\_security\_group\_ids) | List of security groups that have been created during the run. |
| <a name="output_tfe_admin_console_url"></a> [tfe\_admin\_console\_url](#output\_tfe\_admin\_console\_url) | URL of TFE (Replicated) Admin Console based on `route53_failover_fqdn` input. |
| <a name="output_tfe_url"></a> [tfe\_url](#output\_tfe\_url) | URL of TFE application based on `route53_failover_fqdn` input. |
| <a name="output_user_data_script"></a> [user\_data\_script](#output\_user\_data\_script) | base64 decoded user data script that is attached to the launch template |
<!-- END_TF_DOCS -->
