# Overview  

This module showcases an example of utilizing the root module of this repository to build out the following high level components for a TFE deployment inside of AWS in **multiple regions** with an active/standby configuration:  

**Root Module Primary and Secondary Regions**  
-  VPC with Public and Private access  
-  VPC Endpoints  
-  Secrets Manager Secrets  
-  S3 buckets  
-  S3 Cross Region Replication  
-  Global Aurora PostgreSQL cluster  
-  Application Load Balancer, Listeners, and Target Groups  
-  ACM Certificate for Load Balancer  
-  Route 53 entries (Regional record and Failover record)  
-  KMS Encryption Keys  
-  Log Groups for TFE  
-  TFE KeyPair for TFE  

**TFE Module Primary and Secondary Regions**  
-  TFE EC2 AutoScaling Group (in secondary region, the ASG replica count is set to 0)  
-  TFE EC2 Launch Template  

## Failover Testing steps

>**Note**
>
>This assumes you have already deployed the example. We are mimicing a controlled failover as a part of the first portion and a DB failing over without TFE being aware in the second half.

1. Change the `asg_instance_count = 1` to `0` for the `active_tfe` module call and change `asg_min_size = 1` to `0` for the `active_tfe` module call.
2. `terraform apply`
3. Login to AWS and failover the aurora cluster to the secondary region.
4. Change `asg_instance_count = 0` to `1` for the `standby_tfe` module call and change the `asg_min_size = 0` to `1` for the `standby_tfe` module call.
5. `terrform apply`
6. Retry the tfe url after about 7 minutes and make sure it works. Might need to use a different browser or incognito.
7. Login to TFE and add a workspace or project. This is so we can show the configuration changes are present when we fail back.
8. Login to AWS and failover the database cluster to mimic it dropping.
11. Change `asg_instance_count = 0` to `1` for `active_tfe` and `asg_instance_count = 1` to `0` for the `standby_tfe` module call.
12. Change `asg_min_size = 0` to `1` for `active_tfe` and `asg_min_size = 1` to `0` for the `standby_tfe` module call.
10. `terraform apply`
11. Retry the tfe url after about 7 minutes once the run is complete. Ensure that the changes you made from the second site is present when you failed back.

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.4.0 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >=4.55.0 |

## Providers

No providers.

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_active_tfe"></a> [active\_tfe](#module\_active\_tfe) | github.com/hashicorp-modules/terraform-aws-tfe | v0.1.4 |
| <a name="module_pre_req_primary"></a> [pre\_req\_primary](#module\_pre\_req\_primary) | ../../ | n/a |
| <a name="module_pre_req_secondary"></a> [pre\_req\_secondary](#module\_pre\_req\_secondary) | ../../ | n/a |
| <a name="module_standby_tfe"></a> [standby\_tfe](#module\_standby\_tfe) | github.com/hashicorp-modules/terraform-aws-tfe | v0.1.4 |

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_friendly_name_prefix"></a> [friendly\_name\_prefix](#input\_friendly\_name\_prefix) | Friendly name prefix used for tagging and naming AWS resources. | `string` | n/a | yes |
| <a name="input_tfe_hostname"></a> [tfe\_hostname](#input\_tfe\_hostname) | Fully qualified domain name for the TFE instances to use. This is utilized as a string input so that the destroy operations will complete cleanly if you are tearing down a multi-site deployment. | `string` | n/a | yes |
| <a name="input_db_database_name"></a> [db\_database\_name](#input\_db\_database\_name) | Name of the database that will be created and used | `string` | `null` | no |
| <a name="input_db_password"></a> [db\_password](#input\_db\_password) | Password for the DB user. | `string` | `null` | no |
| <a name="input_db_username"></a> [db\_username](#input\_db\_username) | Username for the DB user. | `string` | `"tfe"` | no |
| <a name="input_primary_common_tags"></a> [primary\_common\_tags](#input\_primary\_common\_tags) | Map of common tags for all taggable AWS resources. | `map(string)` | `{}` | no |
| <a name="input_r53_domain_name"></a> [r53\_domain\_name](#input\_r53\_domain\_name) | Route 53 public domain name | `string` | `""` | no |
| <a name="input_region_primary"></a> [region\_primary](#input\_region\_primary) | AWS Primary Region | `string` | `"us-east-2"` | no |
| <a name="input_region_secondary"></a> [region\_secondary](#input\_region\_secondary) | AWS Secondary Region | `string` | `"us-west-2"` | no |
| <a name="input_secondary_common_tags"></a> [secondary\_common\_tags](#input\_secondary\_common\_tags) | Map of common tags for all taggable AWS resources. | `map(string)` | `{}` | no |
| <a name="input_secondary_s3_buckets"></a> [secondary\_s3\_buckets](#input\_secondary\_s3\_buckets) | Object Map that contains the configuration for the S3 logging and bootstrap bucket configuration. | <pre>object({<br>    bootstrap = optional(object({<br>      create                              = optional(bool, true)<br>      bucket_name                         = optional(string, "tfe-bootstrap-bucket")<br>      description                         = optional(string, "Bootstrap bucket for the TFE instances and install")<br>      versioning                          = optional(bool, true)<br>      force_destroy                       = optional(bool, false)<br>      replication                         = optional(bool)<br>      replication_destination_bucket_arn  = optional(string)<br>      replication_destination_kms_key_arn = optional(string)<br>      replication_destination_region      = optional(string)<br>      encrypt                             = optional(bool, true)<br>      bucket_key_enabled                  = optional(bool, true)<br>      kms_key_arn                         = optional(string)<br>      sse_s3_managed_key                  = optional(bool, false)<br>      is_secondary_region                 = optional(bool, false)<br>    }), {})<br>    tfe_app = optional(object({<br>      create                              = optional(bool, true)<br>      bucket_name                         = optional(string, "tfe-app-bucket")<br>      description                         = optional(string, "Object store for TFE")<br>      versioning                          = optional(bool, true)<br>      force_destroy                       = optional(bool, false)<br>      replication                         = optional(bool)<br>      replication_destination_bucket_arn  = optional(string)<br>      replication_destination_kms_key_arn = optional(string)<br>      replication_destination_region      = optional(string)<br>      encrypt                             = optional(bool, true)<br>      bucket_key_enabled                  = optional(bool, true)<br>      kms_key_arn                         = optional(string)<br>      sse_s3_managed_key                  = optional(bool, false)<br>      is_secondary_region                 = optional(bool, false)<br>    }), {})<br>    logging = optional(object({<br>      create                              = optional(bool, true)<br>      bucket_name                         = optional(string, "hashicorp-log-bucket")<br>      versioning                          = optional(bool, false)<br>      force_destroy                       = optional(bool, false)<br>      replication                         = optional(bool, false)<br>      replication_destination_bucket_arn  = optional(string)<br>      replication_destination_kms_key_arn = optional(string)<br>      replication_destination_region      = optional(string)<br>      encrypt                             = optional(bool, true)<br>      bucket_key_enabled                  = optional(bool, true)<br>      kms_key_arn                         = optional(string)<br>      sse_s3_managed_key                  = optional(bool, false)<br>      lifecycle_enabled                   = optional(bool, true)<br>      lifecycle_expiration_days           = optional(number, 7)<br>      is_secondary_region                 = optional(bool, false)<br>    }), {})<br>  })</pre> | `{}` | no |
| <a name="input_secretsmanager_secrets"></a> [secretsmanager\_secrets](#input\_secretsmanager\_secrets) | Object Map that contains various TFE secrets that will be created and stored in AWS Secrets Manager. | <pre>object({<br>    license = optional(object({<br>      name        = optional(string, "tfe-license")<br>      path        = optional(string, null)<br>      description = optional(string, "TFE license")<br>      data        = optional(string, null)<br>    }), {})<br>    tfe_console_password = optional(object({<br>      name        = optional(string, "console-password")<br>      description = optional(string, "Console password used in the TFE installation")<br>      data        = optional(string, null)<br>    }), {})<br>    tfe_enc_password = optional(object({<br>      name        = optional(string, "enc-password")<br>      description = optional(string, "Encryption password used in the TFE installation")<br>      data        = optional(string, null)<br>    }), {})<br>    ca_certificate_bundle = optional(object({<br>      name        = optional(string, null)<br>      path        = optional(string, null)<br>      description = optional(string, "TFE BYO CA certificate bundle")<br>      data        = optional(string, null)<br>    }))<br>    cert_pem_secret = optional(object({<br>      name        = optional(string, null)<br>      path        = optional(string, null)<br>      description = optional(string, "TFE BYO PEM-encoded TLS certificate")<br>      data        = optional(string, null)<br>    }))<br>    cert_pem_private_key_secret = optional(object({<br>      name        = optional(string, null)<br>      path        = optional(string, null)<br>      description = optional(string, "TFE BYO PEM-encoded TLS private key")<br>      data        = optional(string, null)<br>    }))<br>  })</pre> | `{}` | no |
| <a name="input_tfe_ssh_public_key"></a> [tfe\_ssh\_public\_key](#input\_tfe\_ssh\_public\_key) | Public key material for TFE SSH Key Pair. | `string` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_active_acm_certificate_arn"></a> [active\_acm\_certificate\_arn](#output\_active\_acm\_certificate\_arn) | The ARN of the certificate |
| <a name="output_active_acm_certificate_status"></a> [active\_acm\_certificate\_status](#output\_active\_acm\_certificate\_status) | Status of the certificate |
| <a name="output_active_acm_distinct_domain_names"></a> [active\_acm\_distinct\_domain\_names](#output\_active\_acm\_distinct\_domain\_names) | List of distinct domains names used for the validation |
| <a name="output_active_acm_validation_domains"></a> [active\_acm\_validation\_domains](#output\_active\_acm\_validation\_domains) | List of distinct domain validation options. This is useful if subject alternative names contain wildcards |
| <a name="output_active_acm_validation_route53_record_fqdns"></a> [active\_acm\_validation\_route53\_record\_fqdns](#output\_active\_acm\_validation\_route53\_record\_fqdns) | List of FQDNs built using the zone domain and name |
| <a name="output_active_asg_healthcheck_type"></a> [active\_asg\_healthcheck\_type](#output\_active\_asg\_healthcheck\_type) | Type of health check that is associated with the AWS autoscaling group. |
| <a name="output_active_asg_lifecycle_hook_name"></a> [active\_asg\_lifecycle\_hook\_name](#output\_active\_asg\_lifecycle\_hook\_name) | Name of the AWS autoscaling group lifecycle hook that has been created |
| <a name="output_active_asg_name"></a> [active\_asg\_name](#output\_active\_asg\_name) | Name of the AWS autoscaling group that was created during the run. |
| <a name="output_active_asg_target_group_arns"></a> [active\_asg\_target\_group\_arns](#output\_active\_asg\_target\_group\_arns) | List of the target group ARNs that are used for the AWS autoscaling group |
| <a name="output_active_ca_certificate_bundle_secret_arn"></a> [active\_ca\_certificate\_bundle\_secret\_arn](#output\_active\_ca\_certificate\_bundle\_secret\_arn) | AWS Secrets Manager TFE BYO CA certificate secret ARN. |
| <a name="output_active_cert_pem_private_key_secret_arn"></a> [active\_cert\_pem\_private\_key\_secret\_arn](#output\_active\_cert\_pem\_private\_key\_secret\_arn) | AWS Secrets Manager TFE BYO CA certificate private key secret ARN. |
| <a name="output_active_cert_pem_secret_arn"></a> [active\_cert\_pem\_secret\_arn](#output\_active\_cert\_pem\_secret\_arn) | AWS Secrets Manager TFE BYO CA certificate private key secret ARN. |
| <a name="output_active_database_subnet_arns"></a> [active\_database\_subnet\_arns](#output\_active\_database\_subnet\_arns) | List of ARNs of database subnets |
| <a name="output_active_database_subnet_group"></a> [active\_database\_subnet\_group](#output\_active\_database\_subnet\_group) | ID of database subnet group |
| <a name="output_active_database_subnet_group_name"></a> [active\_database\_subnet\_group\_name](#output\_active\_database\_subnet\_group\_name) | Name of database subnet group |
| <a name="output_active_database_subnets"></a> [active\_database\_subnets](#output\_active\_database\_subnets) | List of IDs of database subnets |
| <a name="output_active_database_subnets_cidr_blocks"></a> [active\_database\_subnets\_cidr\_blocks](#output\_active\_database\_subnets\_cidr\_blocks) | List of cidr\_blocks of database subnets |
| <a name="output_active_database_subnets_ipv6_cidr_blocks"></a> [active\_database\_subnets\_ipv6\_cidr\_blocks](#output\_active\_database\_subnets\_ipv6\_cidr\_blocks) | List of IPv6 cidr\_blocks of database subnets in an IPv6 enabled VPC |
| <a name="output_active_db_additional_cluster_endpoints"></a> [active\_db\_additional\_cluster\_endpoints](#output\_active\_db\_additional\_cluster\_endpoints) | A map of additional cluster endpoints and their attributes |
| <a name="output_active_db_cluster_arn"></a> [active\_db\_cluster\_arn](#output\_active\_db\_cluster\_arn) | Amazon Resource Name (ARN) of cluster |
| <a name="output_active_db_cluster_cloudwatch_log_groups"></a> [active\_db\_cluster\_cloudwatch\_log\_groups](#output\_active\_db\_cluster\_cloudwatch\_log\_groups) | Map of CloudWatch log groups created and their attributes |
| <a name="output_active_db_cluster_database_name"></a> [active\_db\_cluster\_database\_name](#output\_active\_db\_cluster\_database\_name) | Name for an automatically created database on cluster creation |
| <a name="output_active_db_cluster_endpoint"></a> [active\_db\_cluster\_endpoint](#output\_active\_db\_cluster\_endpoint) | Writer endpoint for the cluster |
| <a name="output_active_db_cluster_engine_version_actual"></a> [active\_db\_cluster\_engine\_version\_actual](#output\_active\_db\_cluster\_engine\_version\_actual) | The running version of the cluster database |
| <a name="output_active_db_cluster_id"></a> [active\_db\_cluster\_id](#output\_active\_db\_cluster\_id) | The RDS Cluster Identifier |
| <a name="output_active_db_cluster_instances"></a> [active\_db\_cluster\_instances](#output\_active\_db\_cluster\_instances) | A map of cluster instances and their attributes |
| <a name="output_active_db_cluster_members"></a> [active\_db\_cluster\_members](#output\_active\_db\_cluster\_members) | List of RDS Instances that are a part of this cluster |
| <a name="output_active_db_cluster_port"></a> [active\_db\_cluster\_port](#output\_active\_db\_cluster\_port) | The database port |
| <a name="output_active_db_cluster_reader_endpoint"></a> [active\_db\_cluster\_reader\_endpoint](#output\_active\_db\_cluster\_reader\_endpoint) | A read-only endpoint for the cluster, automatically load-balanced across replicas |
| <a name="output_active_db_cluster_resource_id"></a> [active\_db\_cluster\_resource\_id](#output\_active\_db\_cluster\_resource\_id) | The RDS Cluster Resource ID |
| <a name="output_active_db_cluster_role_associations"></a> [active\_db\_cluster\_role\_associations](#output\_active\_db\_cluster\_role\_associations) | A map of IAM roles associated with the cluster and their attributes |
| <a name="output_active_db_enhanced_monitoring_iam_role_arn"></a> [active\_db\_enhanced\_monitoring\_iam\_role\_arn](#output\_active\_db\_enhanced\_monitoring\_iam\_role\_arn) | The Amazon Resource Name (ARN) specifying the enhanced monitoring role |
| <a name="output_active_db_enhanced_monitoring_iam_role_name"></a> [active\_db\_enhanced\_monitoring\_iam\_role\_name](#output\_active\_db\_enhanced\_monitoring\_iam\_role\_name) | The name of the enhanced monitoring role |
| <a name="output_active_db_enhanced_monitoring_iam_role_unique_id"></a> [active\_db\_enhanced\_monitoring\_iam\_role\_unique\_id](#output\_active\_db\_enhanced\_monitoring\_iam\_role\_unique\_id) | Stable and unique string identifying the enhanced monitoring role |
| <a name="output_active_db_global_cluster_id"></a> [active\_db\_global\_cluster\_id](#output\_active\_db\_global\_cluster\_id) | ID of the global cluster that has been created (if specified.) |
| <a name="output_active_db_password"></a> [active\_db\_password](#output\_active\_db\_password) | The database master password |
| <a name="output_active_db_security_group_id"></a> [active\_db\_security\_group\_id](#output\_active\_db\_security\_group\_id) | The security group ID of the cluster |
| <a name="output_active_db_username"></a> [active\_db\_username](#output\_active\_db\_username) | The database master username |
| <a name="output_active_default_security_group_id"></a> [active\_default\_security\_group\_id](#output\_active\_default\_security\_group\_id) | The ID of the security group created by default on VPC creation |
| <a name="output_active_kms_key_alias"></a> [active\_kms\_key\_alias](#output\_active\_kms\_key\_alias) | The KMS Key Alias |
| <a name="output_active_kms_key_alias_arn"></a> [active\_kms\_key\_alias\_arn](#output\_active\_kms\_key\_alias\_arn) | The KMS Key Alias arn |
| <a name="output_active_kms_key_arn"></a> [active\_kms\_key\_arn](#output\_active\_kms\_key\_arn) | The KMS key used to encrypt data. |
| <a name="output_active_launch_template_name"></a> [active\_launch\_template\_name](#output\_active\_launch\_template\_name) | Name of the AWS launch template that was created during the run |
| <a name="output_active_lb_arn"></a> [active\_lb\_arn](#output\_active\_lb\_arn) | The Resource Identifier of the LB |
| <a name="output_active_lb_dns_name"></a> [active\_lb\_dns\_name](#output\_active\_lb\_dns\_name) | The DNS name created with the LB |
| <a name="output_active_lb_internal"></a> [active\_lb\_internal](#output\_active\_lb\_internal) | Boolean value of the internal/external status of the LB.  Determines if the LB gets Elastic IPs assigned |
| <a name="output_active_lb_name"></a> [active\_lb\_name](#output\_active\_lb\_name) | Name of the LB |
| <a name="output_active_lb_security_group_ids"></a> [active\_lb\_security\_group\_ids](#output\_active\_lb\_security\_group\_ids) | List of security group IDs in use by the LB |
| <a name="output_active_lb_tg_arns"></a> [active\_lb\_tg\_arns](#output\_active\_lb\_tg\_arns) | List of target group ARNs for LB |
| <a name="output_active_lb_type"></a> [active\_lb\_type](#output\_active\_lb\_type) | Type of LB created (ALB or NLB) |
| <a name="output_active_lb_zone_id"></a> [active\_lb\_zone\_id](#output\_active\_lb\_zone\_id) | The Zone ID of the LB |
| <a name="output_active_license_arn"></a> [active\_license\_arn](#output\_active\_license\_arn) | AWS Secrets Manager tfe\_license secret ARN. |
| <a name="output_active_private_route_table_ids"></a> [active\_private\_route\_table\_ids](#output\_active\_private\_route\_table\_ids) | List of IDs of private route tables |
| <a name="output_active_private_subnet_arns"></a> [active\_private\_subnet\_arns](#output\_active\_private\_subnet\_arns) | List of ARNs of private subnets |
| <a name="output_active_private_subnets"></a> [active\_private\_subnets](#output\_active\_private\_subnets) | List of IDs of private subnets |
| <a name="output_active_private_subnets_cidr_blocks"></a> [active\_private\_subnets\_cidr\_blocks](#output\_active\_private\_subnets\_cidr\_blocks) | List of cidr\_blocks of private subnets |
| <a name="output_active_private_subnets_ipv6_cidr_blocks"></a> [active\_private\_subnets\_ipv6\_cidr\_blocks](#output\_active\_private\_subnets\_ipv6\_cidr\_blocks) | List of IPv6 cidr\_blocks of private subnets in an IPv6 enabled VPC |
| <a name="output_active_public_route_table_ids"></a> [active\_public\_route\_table\_ids](#output\_active\_public\_route\_table\_ids) | List of IDs of public route tables |
| <a name="output_active_public_subnet_arns"></a> [active\_public\_subnet\_arns](#output\_active\_public\_subnet\_arns) | List of ARNs of public subnets |
| <a name="output_active_public_subnets"></a> [active\_public\_subnets](#output\_active\_public\_subnets) | List of IDs of public subnets |
| <a name="output_active_public_subnets_cidr_blocks"></a> [active\_public\_subnets\_cidr\_blocks](#output\_active\_public\_subnets\_cidr\_blocks) | List of cidr\_blocks of public subnets |
| <a name="output_active_public_subnets_ipv6_cidr_blocks"></a> [active\_public\_subnets\_ipv6\_cidr\_blocks](#output\_active\_public\_subnets\_ipv6\_cidr\_blocks) | List of IPv6 cidr\_blocks of public subnets in an IPv6 enabled VPC |
| <a name="output_active_region"></a> [active\_region](#output\_active\_region) | The AWS region where the resources have been created |
| <a name="output_active_route53_failover_fqdn"></a> [active\_route53\_failover\_fqdn](#output\_active\_route53\_failover\_fqdn) | FQDN of failover LB Route53 record |
| <a name="output_active_route53_failover_record_name"></a> [active\_route53\_failover\_record\_name](#output\_active\_route53\_failover\_record\_name) | Name of the failover LB Route53 record name |
| <a name="output_active_route53_regional_fqdn"></a> [active\_route53\_regional\_fqdn](#output\_active\_route53\_regional\_fqdn) | FQDN of regional LB Route53 record |
| <a name="output_active_route53_regional_record_name"></a> [active\_route53\_regional\_record\_name](#output\_active\_route53\_regional\_record\_name) | Name of the regional LB Route53 record name |
| <a name="output_active_s3_bootstrap_bucket_arn"></a> [active\_s3\_bootstrap\_bucket\_arn](#output\_active\_s3\_bootstrap\_bucket\_arn) | ARN of S3 'bootstrap' bucket |
| <a name="output_active_s3_bootstrap_bucket_name"></a> [active\_s3\_bootstrap\_bucket\_name](#output\_active\_s3\_bootstrap\_bucket\_name) | Name of S3 'bootstrap' bucket. |
| <a name="output_active_s3_bootstrap_bucket_replication_policy"></a> [active\_s3\_bootstrap\_bucket\_replication\_policy](#output\_active\_s3\_bootstrap\_bucket\_replication\_policy) | Replication policy of the S3 'bootstrap' bucket. |
| <a name="output_active_s3_bucket_arn_list"></a> [active\_s3\_bucket\_arn\_list](#output\_active\_s3\_bucket\_arn\_list) | A list of the ARNs for the buckets that have been configured |
| <a name="output_active_s3_log_bucket_arn"></a> [active\_s3\_log\_bucket\_arn](#output\_active\_s3\_log\_bucket\_arn) | Name of S3 'logging' bucket. |
| <a name="output_active_s3_log_bucket_name"></a> [active\_s3\_log\_bucket\_name](#output\_active\_s3\_log\_bucket\_name) | Name of S3 'logging' bucket. |
| <a name="output_active_s3_log_bucket_replication_policy"></a> [active\_s3\_log\_bucket\_replication\_policy](#output\_active\_s3\_log\_bucket\_replication\_policy) | Replication policy of the S3 'logging' bucket. |
| <a name="output_active_s3_replication_iam_role_arn"></a> [active\_s3\_replication\_iam\_role\_arn](#output\_active\_s3\_replication\_iam\_role\_arn) | ARN of IAM Role for S3 replication. |
| <a name="output_active_s3_tfe_app_bucket_arn"></a> [active\_s3\_tfe\_app\_bucket\_arn](#output\_active\_s3\_tfe\_app\_bucket\_arn) | ARN of the S3 Terraform Enterprise Object Store bucket. |
| <a name="output_active_s3_tfe_app_bucket_name"></a> [active\_s3\_tfe\_app\_bucket\_name](#output\_active\_s3\_tfe\_app\_bucket\_name) | Name of S3 S3 Terraform Enterprise Object Store bucket. |
| <a name="output_active_s3_tfe_app_bucket_replication_policy"></a> [active\_s3\_tfe\_app\_bucket\_replication\_policy](#output\_active\_s3\_tfe\_app\_bucket\_replication\_policy) | Replication policy of the S3 Terraform Enterprise Object Store bucket. |
| <a name="output_active_secret_arn_list"></a> [active\_secret\_arn\_list](#output\_active\_secret\_arn\_list) | A list of AWS Secrets Manager Arns produced by the module |
| <a name="output_active_security_group_ids"></a> [active\_security\_group\_ids](#output\_active\_security\_group\_ids) | List of security groups that have been created during the run. |
| <a name="output_active_tfe_admin_console_url"></a> [active\_tfe\_admin\_console\_url](#output\_active\_tfe\_admin\_console\_url) | URL of TFE (Replicated) Admin Console based on `route53_failover_fqdn` input. |
| <a name="output_active_tfe_asg_hook_value"></a> [active\_tfe\_asg\_hook\_value](#output\_active\_tfe\_asg\_hook\_value) | Value for the `asg-hook` tag that will be attatched to the TFE instance in the other module. Use this value to ensure the lifecycle hook is updated during deployment. |
| <a name="output_active_tfe_console_password_arn"></a> [active\_tfe\_console\_password\_arn](#output\_active\_tfe\_console\_password\_arn) | AWS Secrets Manager console\_password secret ARN. |
| <a name="output_active_tfe_enc_password_arn"></a> [active\_tfe\_enc\_password\_arn](#output\_active\_tfe\_enc\_password\_arn) | AWS Secrets Manager enc\_password secret ARN. |
| <a name="output_active_tfe_iam_instance_profile"></a> [active\_tfe\_iam\_instance\_profile](#output\_active\_tfe\_iam\_instance\_profile) | ARN of IAM Instance Profile for TFE Instance Role |
| <a name="output_active_tfe_iam_managed_policy_arn"></a> [active\_tfe\_iam\_managed\_policy\_arn](#output\_active\_tfe\_iam\_managed\_policy\_arn) | ARN of IAM Managed Policy for TFE Instance Role |
| <a name="output_active_tfe_iam_managed_policy_name"></a> [active\_tfe\_iam\_managed\_policy\_name](#output\_active\_tfe\_iam\_managed\_policy\_name) | Name of IAM Managed Policy for TFE Instance Role |
| <a name="output_active_tfe_iam_role_arn"></a> [active\_tfe\_iam\_role\_arn](#output\_active\_tfe\_iam\_role\_arn) | ARN of IAM Role in use by TFE Instances |
| <a name="output_active_tfe_iam_role_name"></a> [active\_tfe\_iam\_role\_name](#output\_active\_tfe\_iam\_role\_name) | Name of IAM Role in use by TFE Instances |
| <a name="output_active_tfe_keypair_arn"></a> [active\_tfe\_keypair\_arn](#output\_active\_tfe\_keypair\_arn) | ARN of the keypair that was created (if specified). |
| <a name="output_active_tfe_keypair_fingerprint"></a> [active\_tfe\_keypair\_fingerprint](#output\_active\_tfe\_keypair\_fingerprint) | Fingerprint of TFE SSH Key Pair. |
| <a name="output_active_tfe_keypair_id"></a> [active\_tfe\_keypair\_id](#output\_active\_tfe\_keypair\_id) | ID of TFE SSH Key Pair. |
| <a name="output_active_tfe_keypair_name"></a> [active\_tfe\_keypair\_name](#output\_active\_tfe\_keypair\_name) | Name of the keypair that was created (if specified). |
| <a name="output_active_tfe_log_group_name"></a> [active\_tfe\_log\_group\_name](#output\_active\_tfe\_log\_group\_name) | AWS CloudWatch Log Group Name. |
| <a name="output_active_tfe_url"></a> [active\_tfe\_url](#output\_active\_tfe\_url) | URL of TFE application based on `route53_failover_fqdn` input. |
| <a name="output_active_user_data_script"></a> [active\_user\_data\_script](#output\_active\_user\_data\_script) | base64 decoded user data script that is attached to the launch template |
| <a name="output_active_vpc_arn"></a> [active\_vpc\_arn](#output\_active\_vpc\_arn) | The ARN of the VPC |
| <a name="output_active_vpc_cidr_block"></a> [active\_vpc\_cidr\_block](#output\_active\_vpc\_cidr\_block) | The CIDR block of the VPC |
| <a name="output_active_vpc_id"></a> [active\_vpc\_id](#output\_active\_vpc\_id) | The ID of the VPC |
| <a name="output_standby_acm_certificate_arn"></a> [standby\_acm\_certificate\_arn](#output\_standby\_acm\_certificate\_arn) | The ARN of the certificate |
| <a name="output_standby_acm_certificate_status"></a> [standby\_acm\_certificate\_status](#output\_standby\_acm\_certificate\_status) | Status of the certificate |
| <a name="output_standby_acm_distinct_domain_names"></a> [standby\_acm\_distinct\_domain\_names](#output\_standby\_acm\_distinct\_domain\_names) | List of distinct domains names used for the validation |
| <a name="output_standby_acm_validation_domains"></a> [standby\_acm\_validation\_domains](#output\_standby\_acm\_validation\_domains) | List of distinct domain validation options. This is useful if subject alternative names contain wildcards |
| <a name="output_standby_acm_validation_route53_record_fqdns"></a> [standby\_acm\_validation\_route53\_record\_fqdns](#output\_standby\_acm\_validation\_route53\_record\_fqdns) | List of FQDNs built using the zone domain and name |
| <a name="output_standby_asg_healthcheck_type"></a> [standby\_asg\_healthcheck\_type](#output\_standby\_asg\_healthcheck\_type) | Type of health check that is associated with the AWS autoscaling group. |
| <a name="output_standby_asg_lifecycle_hook_name"></a> [standby\_asg\_lifecycle\_hook\_name](#output\_standby\_asg\_lifecycle\_hook\_name) | Name of the AWS autoscaling group lifecycle hook that has been created |
| <a name="output_standby_asg_name"></a> [standby\_asg\_name](#output\_standby\_asg\_name) | Name of the AWS autoscaling group that was created during the run. |
| <a name="output_standby_asg_target_group_arns"></a> [standby\_asg\_target\_group\_arns](#output\_standby\_asg\_target\_group\_arns) | List of the target group ARNs that are used for the AWS autoscaling group |
| <a name="output_standby_ca_certificate_bundle_secret_arn"></a> [standby\_ca\_certificate\_bundle\_secret\_arn](#output\_standby\_ca\_certificate\_bundle\_secret\_arn) | AWS Secrets Manager TFE BYO CA certificate secret ARN. |
| <a name="output_standby_cert_pem_private_key_secret_arn"></a> [standby\_cert\_pem\_private\_key\_secret\_arn](#output\_standby\_cert\_pem\_private\_key\_secret\_arn) | AWS Secrets Manager TFE BYO CA certificate private key secret ARN. |
| <a name="output_standby_cert_pem_secret_arn"></a> [standby\_cert\_pem\_secret\_arn](#output\_standby\_cert\_pem\_secret\_arn) | AWS Secrets Manager TFE BYO CA certificate private key secret ARN. |
| <a name="output_standby_database_subnet_arns"></a> [standby\_database\_subnet\_arns](#output\_standby\_database\_subnet\_arns) | List of ARNs of database subnets |
| <a name="output_standby_database_subnet_group"></a> [standby\_database\_subnet\_group](#output\_standby\_database\_subnet\_group) | ID of database subnet group |
| <a name="output_standby_database_subnet_group_name"></a> [standby\_database\_subnet\_group\_name](#output\_standby\_database\_subnet\_group\_name) | Name of database subnet group |
| <a name="output_standby_database_subnets"></a> [standby\_database\_subnets](#output\_standby\_database\_subnets) | List of IDs of database subnets |
| <a name="output_standby_database_subnets_cidr_blocks"></a> [standby\_database\_subnets\_cidr\_blocks](#output\_standby\_database\_subnets\_cidr\_blocks) | List of cidr\_blocks of database subnets |
| <a name="output_standby_database_subnets_ipv6_cidr_blocks"></a> [standby\_database\_subnets\_ipv6\_cidr\_blocks](#output\_standby\_database\_subnets\_ipv6\_cidr\_blocks) | List of IPv6 cidr\_blocks of database subnets in an IPv6 enabled VPC |
| <a name="output_standby_db_additional_cluster_endpoints"></a> [standby\_db\_additional\_cluster\_endpoints](#output\_standby\_db\_additional\_cluster\_endpoints) | A map of additional cluster endpoints and their attributes |
| <a name="output_standby_db_cluster_arn"></a> [standby\_db\_cluster\_arn](#output\_standby\_db\_cluster\_arn) | Amazon Resource Name (ARN) of cluster |
| <a name="output_standby_db_cluster_cloudwatch_log_groups"></a> [standby\_db\_cluster\_cloudwatch\_log\_groups](#output\_standby\_db\_cluster\_cloudwatch\_log\_groups) | Map of CloudWatch log groups created and their attributes |
| <a name="output_standby_db_cluster_database_name"></a> [standby\_db\_cluster\_database\_name](#output\_standby\_db\_cluster\_database\_name) | Name for an automatically created database on cluster creation |
| <a name="output_standby_db_cluster_endpoint"></a> [standby\_db\_cluster\_endpoint](#output\_standby\_db\_cluster\_endpoint) | Writer endpoint for the cluster |
| <a name="output_standby_db_cluster_engine_version_actual"></a> [standby\_db\_cluster\_engine\_version\_actual](#output\_standby\_db\_cluster\_engine\_version\_actual) | The running version of the cluster database |
| <a name="output_standby_db_cluster_id"></a> [standby\_db\_cluster\_id](#output\_standby\_db\_cluster\_id) | The RDS Cluster Identifier |
| <a name="output_standby_db_cluster_instances"></a> [standby\_db\_cluster\_instances](#output\_standby\_db\_cluster\_instances) | A map of cluster instances and their attributes |
| <a name="output_standby_db_cluster_members"></a> [standby\_db\_cluster\_members](#output\_standby\_db\_cluster\_members) | List of RDS Instances that are a part of this cluster |
| <a name="output_standby_db_cluster_port"></a> [standby\_db\_cluster\_port](#output\_standby\_db\_cluster\_port) | The database port |
| <a name="output_standby_db_cluster_reader_endpoint"></a> [standby\_db\_cluster\_reader\_endpoint](#output\_standby\_db\_cluster\_reader\_endpoint) | A read-only endpoint for the cluster, automatically load-balanced across replicas |
| <a name="output_standby_db_cluster_resource_id"></a> [standby\_db\_cluster\_resource\_id](#output\_standby\_db\_cluster\_resource\_id) | The RDS Cluster Resource ID |
| <a name="output_standby_db_cluster_role_associations"></a> [standby\_db\_cluster\_role\_associations](#output\_standby\_db\_cluster\_role\_associations) | A map of IAM roles associated with the cluster and their attributes |
| <a name="output_standby_db_enhanced_monitoring_iam_role_arn"></a> [standby\_db\_enhanced\_monitoring\_iam\_role\_arn](#output\_standby\_db\_enhanced\_monitoring\_iam\_role\_arn) | The Amazon Resource Name (ARN) specifying the enhanced monitoring role |
| <a name="output_standby_db_enhanced_monitoring_iam_role_name"></a> [standby\_db\_enhanced\_monitoring\_iam\_role\_name](#output\_standby\_db\_enhanced\_monitoring\_iam\_role\_name) | The name of the enhanced monitoring role |
| <a name="output_standby_db_enhanced_monitoring_iam_role_unique_id"></a> [standby\_db\_enhanced\_monitoring\_iam\_role\_unique\_id](#output\_standby\_db\_enhanced\_monitoring\_iam\_role\_unique\_id) | Stable and unique string identifying the enhanced monitoring role |
| <a name="output_standby_db_global_cluster_id"></a> [standby\_db\_global\_cluster\_id](#output\_standby\_db\_global\_cluster\_id) | ID of the global cluster that has been created (if specified.) |
| <a name="output_standby_db_password"></a> [standby\_db\_password](#output\_standby\_db\_password) | The database master password |
| <a name="output_standby_db_security_group_id"></a> [standby\_db\_security\_group\_id](#output\_standby\_db\_security\_group\_id) | The security group ID of the cluster |
| <a name="output_standby_db_username"></a> [standby\_db\_username](#output\_standby\_db\_username) | The database master username |
| <a name="output_standby_default_security_group_id"></a> [standby\_default\_security\_group\_id](#output\_standby\_default\_security\_group\_id) | The ID of the security group created by default on VPC creation |
| <a name="output_standby_kms_key_alias"></a> [standby\_kms\_key\_alias](#output\_standby\_kms\_key\_alias) | The KMS Key Alias |
| <a name="output_standby_kms_key_alias_arn"></a> [standby\_kms\_key\_alias\_arn](#output\_standby\_kms\_key\_alias\_arn) | The KMS Key Alias arn |
| <a name="output_standby_kms_key_arn"></a> [standby\_kms\_key\_arn](#output\_standby\_kms\_key\_arn) | The KMS key used to encrypt data. |
| <a name="output_standby_launch_template_name"></a> [standby\_launch\_template\_name](#output\_standby\_launch\_template\_name) | Name of the AWS launch template that was created during the run |
| <a name="output_standby_lb_arn"></a> [standby\_lb\_arn](#output\_standby\_lb\_arn) | The Resource Identifier of the LB |
| <a name="output_standby_lb_dns_name"></a> [standby\_lb\_dns\_name](#output\_standby\_lb\_dns\_name) | The DNS name created with the LB |
| <a name="output_standby_lb_internal"></a> [standby\_lb\_internal](#output\_standby\_lb\_internal) | Boolean value of the internal/external status of the LB.  Determines if the LB gets Elastic IPs assigned |
| <a name="output_standby_lb_name"></a> [standby\_lb\_name](#output\_standby\_lb\_name) | Name of the LB |
| <a name="output_standby_lb_security_group_ids"></a> [standby\_lb\_security\_group\_ids](#output\_standby\_lb\_security\_group\_ids) | List of security group IDs in use by the LB |
| <a name="output_standby_lb_tg_arns"></a> [standby\_lb\_tg\_arns](#output\_standby\_lb\_tg\_arns) | List of target group ARNs for LB |
| <a name="output_standby_lb_type"></a> [standby\_lb\_type](#output\_standby\_lb\_type) | Type of LB created (ALB or NLB) |
| <a name="output_standby_lb_zone_id"></a> [standby\_lb\_zone\_id](#output\_standby\_lb\_zone\_id) | The Zone ID of the LB |
| <a name="output_standby_license_arn"></a> [standby\_license\_arn](#output\_standby\_license\_arn) | AWS Secrets Manager tfe\_license secret ARN. |
| <a name="output_standby_private_route_table_ids"></a> [standby\_private\_route\_table\_ids](#output\_standby\_private\_route\_table\_ids) | List of IDs of private route tables |
| <a name="output_standby_private_subnet_arns"></a> [standby\_private\_subnet\_arns](#output\_standby\_private\_subnet\_arns) | List of ARNs of private subnets |
| <a name="output_standby_private_subnets"></a> [standby\_private\_subnets](#output\_standby\_private\_subnets) | List of IDs of private subnets |
| <a name="output_standby_private_subnets_cidr_blocks"></a> [standby\_private\_subnets\_cidr\_blocks](#output\_standby\_private\_subnets\_cidr\_blocks) | List of cidr\_blocks of private subnets |
| <a name="output_standby_private_subnets_ipv6_cidr_blocks"></a> [standby\_private\_subnets\_ipv6\_cidr\_blocks](#output\_standby\_private\_subnets\_ipv6\_cidr\_blocks) | List of IPv6 cidr\_blocks of private subnets in an IPv6 enabled VPC |
| <a name="output_standby_public_route_table_ids"></a> [standby\_public\_route\_table\_ids](#output\_standby\_public\_route\_table\_ids) | List of IDs of public route tables |
| <a name="output_standby_public_subnet_arns"></a> [standby\_public\_subnet\_arns](#output\_standby\_public\_subnet\_arns) | List of ARNs of public subnets |
| <a name="output_standby_public_subnets"></a> [standby\_public\_subnets](#output\_standby\_public\_subnets) | List of IDs of public subnets |
| <a name="output_standby_public_subnets_cidr_blocks"></a> [standby\_public\_subnets\_cidr\_blocks](#output\_standby\_public\_subnets\_cidr\_blocks) | List of cidr\_blocks of public subnets |
| <a name="output_standby_public_subnets_ipv6_cidr_blocks"></a> [standby\_public\_subnets\_ipv6\_cidr\_blocks](#output\_standby\_public\_subnets\_ipv6\_cidr\_blocks) | List of IPv6 cidr\_blocks of public subnets in an IPv6 enabled VPC |
| <a name="output_standby_region"></a> [standby\_region](#output\_standby\_region) | The AWS region where the resources have been created |
| <a name="output_standby_route53_failover_fqdn"></a> [standby\_route53\_failover\_fqdn](#output\_standby\_route53\_failover\_fqdn) | FQDN of failover LB Route53 record |
| <a name="output_standby_route53_failover_record_name"></a> [standby\_route53\_failover\_record\_name](#output\_standby\_route53\_failover\_record\_name) | Name of the failover LB Route53 record name |
| <a name="output_standby_route53_regional_fqdn"></a> [standby\_route53\_regional\_fqdn](#output\_standby\_route53\_regional\_fqdn) | FQDN of regional LB Route53 record |
| <a name="output_standby_route53_regional_record_name"></a> [standby\_route53\_regional\_record\_name](#output\_standby\_route53\_regional\_record\_name) | Name of the regional LB Route53 record name |
| <a name="output_standby_s3_bootstrap_bucket_arn"></a> [standby\_s3\_bootstrap\_bucket\_arn](#output\_standby\_s3\_bootstrap\_bucket\_arn) | ARN of S3 'bootstrap' bucket |
| <a name="output_standby_s3_bootstrap_bucket_name"></a> [standby\_s3\_bootstrap\_bucket\_name](#output\_standby\_s3\_bootstrap\_bucket\_name) | Name of S3 'bootstrap' bucket. |
| <a name="output_standby_s3_bootstrap_bucket_replication_policy"></a> [standby\_s3\_bootstrap\_bucket\_replication\_policy](#output\_standby\_s3\_bootstrap\_bucket\_replication\_policy) | Replication policy of the S3 'bootstrap' bucket. |
| <a name="output_standby_s3_bucket_arn_list"></a> [standby\_s3\_bucket\_arn\_list](#output\_standby\_s3\_bucket\_arn\_list) | A list of the ARNs for the buckets that have been configured |
| <a name="output_standby_s3_log_bucket_arn"></a> [standby\_s3\_log\_bucket\_arn](#output\_standby\_s3\_log\_bucket\_arn) | Name of S3 'logging' bucket. |
| <a name="output_standby_s3_log_bucket_name"></a> [standby\_s3\_log\_bucket\_name](#output\_standby\_s3\_log\_bucket\_name) | Name of S3 'logging' bucket. |
| <a name="output_standby_s3_log_bucket_replication_policy"></a> [standby\_s3\_log\_bucket\_replication\_policy](#output\_standby\_s3\_log\_bucket\_replication\_policy) | Replication policy of the S3 'logging' bucket. |
| <a name="output_standby_s3_replication_iam_role_arn"></a> [standby\_s3\_replication\_iam\_role\_arn](#output\_standby\_s3\_replication\_iam\_role\_arn) | ARN of IAM Role for S3 replication. |
| <a name="output_standby_s3_tfe_app_bucket_arn"></a> [standby\_s3\_tfe\_app\_bucket\_arn](#output\_standby\_s3\_tfe\_app\_bucket\_arn) | ARN of the S3 Terraform Enterprise Object Store bucket. |
| <a name="output_standby_s3_tfe_app_bucket_name"></a> [standby\_s3\_tfe\_app\_bucket\_name](#output\_standby\_s3\_tfe\_app\_bucket\_name) | Name of S3 S3 Terraform Enterprise Object Store bucket. |
| <a name="output_standby_s3_tfe_app_bucket_replication_policy"></a> [standby\_s3\_tfe\_app\_bucket\_replication\_policy](#output\_standby\_s3\_tfe\_app\_bucket\_replication\_policy) | Replication policy of the S3 Terraform Enterprise Object Store bucket. |
| <a name="output_standby_secret_arn_list"></a> [standby\_secret\_arn\_list](#output\_standby\_secret\_arn\_list) | A list of AWS Secrets Manager Arns produced by the module |
| <a name="output_standby_security_group_ids"></a> [standby\_security\_group\_ids](#output\_standby\_security\_group\_ids) | List of security groups that have been created during the run. |
| <a name="output_standby_tfe_admin_console_url"></a> [standby\_tfe\_admin\_console\_url](#output\_standby\_tfe\_admin\_console\_url) | URL of TFE (Replicated) Admin Console based on `route53_failover_fqdn` input. |
| <a name="output_standby_tfe_asg_hook_value"></a> [standby\_tfe\_asg\_hook\_value](#output\_standby\_tfe\_asg\_hook\_value) | Value for the `asg-hook` tag that will be attatched to the TFE instance in the other module. Use this value to ensure the lifecycle hook is updated during deployment. |
| <a name="output_standby_tfe_console_password_arn"></a> [standby\_tfe\_console\_password\_arn](#output\_standby\_tfe\_console\_password\_arn) | AWS Secrets Manager console\_password secret ARN. |
| <a name="output_standby_tfe_enc_password_arn"></a> [standby\_tfe\_enc\_password\_arn](#output\_standby\_tfe\_enc\_password\_arn) | AWS Secrets Manager enc\_password secret ARN. |
| <a name="output_standby_tfe_iam_instance_profile"></a> [standby\_tfe\_iam\_instance\_profile](#output\_standby\_tfe\_iam\_instance\_profile) | ARN of IAM Instance Profile for TFE Instance Role |
| <a name="output_standby_tfe_iam_managed_policy_arn"></a> [standby\_tfe\_iam\_managed\_policy\_arn](#output\_standby\_tfe\_iam\_managed\_policy\_arn) | ARN of IAM Managed Policy for TFE Instance Role |
| <a name="output_standby_tfe_iam_managed_policy_name"></a> [standby\_tfe\_iam\_managed\_policy\_name](#output\_standby\_tfe\_iam\_managed\_policy\_name) | Name of IAM Managed Policy for TFE Instance Role |
| <a name="output_standby_tfe_iam_role_arn"></a> [standby\_tfe\_iam\_role\_arn](#output\_standby\_tfe\_iam\_role\_arn) | ARN of IAM Role in use by TFE Instances |
| <a name="output_standby_tfe_iam_role_name"></a> [standby\_tfe\_iam\_role\_name](#output\_standby\_tfe\_iam\_role\_name) | Name of IAM Role in use by TFE Instances |
| <a name="output_standby_tfe_keypair_arn"></a> [standby\_tfe\_keypair\_arn](#output\_standby\_tfe\_keypair\_arn) | ARN of the keypair that was created (if specified). |
| <a name="output_standby_tfe_keypair_fingerprint"></a> [standby\_tfe\_keypair\_fingerprint](#output\_standby\_tfe\_keypair\_fingerprint) | Fingerprint of TFE SSH Key Pair. |
| <a name="output_standby_tfe_keypair_id"></a> [standby\_tfe\_keypair\_id](#output\_standby\_tfe\_keypair\_id) | ID of TFE SSH Key Pair. |
| <a name="output_standby_tfe_keypair_name"></a> [standby\_tfe\_keypair\_name](#output\_standby\_tfe\_keypair\_name) | Name of the keypair that was created (if specified). |
| <a name="output_standby_tfe_log_group_name"></a> [standby\_tfe\_log\_group\_name](#output\_standby\_tfe\_log\_group\_name) | AWS CloudWatch Log Group Name. |
| <a name="output_standby_tfe_url"></a> [standby\_tfe\_url](#output\_standby\_tfe\_url) | URL of TFE application based on `route53_failover_fqdn` input. |
| <a name="output_standby_user_data_script"></a> [standby\_user\_data\_script](#output\_standby\_user\_data\_script) | base64 decoded user data script that is attached to the launch template |
| <a name="output_standby_vpc_arn"></a> [standby\_vpc\_arn](#output\_standby\_vpc\_arn) | The ARN of the VPC |
| <a name="output_standby_vpc_cidr_block"></a> [standby\_vpc\_cidr\_block](#output\_standby\_vpc\_cidr\_block) | The CIDR block of the VPC |
| <a name="output_standby_vpc_id"></a> [standby\_vpc\_id](#output\_standby\_vpc\_id) | The ID of the VPC |
<!-- END_TF_DOCS -->
