# terraform-kubernetes-tfc-agents

Terraform module to deploy TFC Agents on Kubernetes. This should work for Kubernetes deployments on any cloud, however this has only been tested with GKE so far.

## Prereqs

- Agent Pool configured in either TFC/TFE
- Agent Token
- A Kubernetes cluster created (Currently only tested with GKE)
- Authentication configured for Kubernetes Provider

<p>&nbsp;</p>

## Usage

```hcl
module "tfc_agent" {
  source = "../.."

  # --- Common --- #
  friendly_name_prefix = var.friendly_name_prefix
  common_labels        = var.common_labels

  # --- Kubernetes --- #
  tfc_agent_replicas = var.tfc_agent_replicas

  # --- TFC Agents --- #
  tfc_agent_name    = var.tfc_agent_name
  tfc_agent_token   = var.tfc_agent_token
}
```

> Note: see the [tests/main](./tests/) directory for an example Terraform configuration to deploy this module.  
> Populate the [terraform.tfvars.example](./tests/main/terraform.tfvars.example) with meaningful values and remove the `.example` file extension.

<p>&nbsp;</p>

### Kubernetes

- This requires a Kubernetes cluster has been created
- Egress is the only network requirement, there is no need for an ingress
- By default, only one pod will be deployed. This can be scaled up with the `tfc_agent_replicas` variable


<p>&nbsp;</p>

### Cloud Agents

- By default this will use the latest version of the Docker container for the TFC Agents
- Single mode can be enabled with the `tfc_agent_single` variable being set to true
  - This will cause the agent to exit after a single plan or apply, which will cause the pod to be removed and a new one created. 
    There is a delay when this occurs, so the `tfc_agent_replicas` should be greater than 1.

<p>&nbsp;</p>