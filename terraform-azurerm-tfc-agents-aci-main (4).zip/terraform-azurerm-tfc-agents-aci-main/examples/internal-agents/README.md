# Internal Agents - Custom VNET, Subnet, and IP Addressing
This example deploys a TFC agent into Azure Container Instances using an existing VNET and private subnet or public subnet.

## Using This Example
1. Ensure the following prerequsites exist in your Azure Subscription:
    - An Existing Resource Group
    - An Existing VNET
    - An Existing Subnet with delegation 'Microsoft.ContainerInstance'
    - An Existing NAT Gateway inside the subnet if it is a private subnet.
    - Any Network Security Groups must allow egress to Terraform Cloud.
1. Rename the `terraform.tfvars.example` file to `terraform.tfvars`
2. Populate the values.
3. Terraform init, plan, and apply.
4. Verify that the Terraform Cloud Agent registers to your Terraform Cloud Org.

## Providers

## Requirements

| Name | Version |
|------|---------|
| terraform | >= 1.2.6 |
| azurerm | 3.15.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| tfc-agents-aci | ../.. | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| agent\_image | The registry/image:tag\_Version to use for the agent. Default = hashicorp/tfc-agent:latest | `string` | `"hashicorp/tfc-agent:latest"` | no |
| agent\_log\_level | The log verbosity. Level options include 'trace', 'debug', 'info', 'warn', and 'error'. Log levels have a progressive level of data sensitivy. The 'info', 'warn', and 'error' levels are considered generally safe for log collection and don't include sensitive information. The 'debug' log level may include internal system details, such as specific commands and arguments including paths to user data on the local filesystem. The 'trace' log level is the most sensitive and may include personally identifiable information, secrets, pre-authorized internal URLs, and other sensitive material. | `string` | `"info"` | no |
| common\_tags | Map of common tags for taggable AWS resources. | `map(string)` | `{}` | no |
| cpu | Number of cpu units used by the container. | `string` | `"1.0"` | no |
| location | The location of the resources. | `string` | `"East US"` | no |
| log\_analytics\_workspace\_retention | The number of days to retain logs. | `number` | `"30"` | no |
| make\_private | The option to use private IP addresses over public IP addresses. | `bool` | `true` | no |
| memory | Amount of memory used by the container. | `string` | `"2.0"` | no |
| private\_subnet\_id | The ID of the private delegated subnet to place the container into. Only used when `make_private` set to true. | `string` | `""` | no |
| resource\_group\_name | The name of an existing resource group | `string` | n/a | yes |
| tfc\_address | Hostname of self-hosted TFE instance. Leave default if TFC is in use. | `string` | `"https://app.terraform.io"` | no |
| tfc\_agent\_name | The name of the agent. | `string` | `"tfc-agent"` | no |
| tfc\_agent\_token | Agent pool token to authenticate to TFC/TFE when cloud agents are instantiated. | `string` | n/a | yes |
joshuatracy@joshuatracy-V1FW0Q7CVW terraform-azurerm-tfc-agents-aci % cd examples/internal-agents 
joshuatracy@joshuatracy-V1FW0Q7CVW internal-agents % terraform-docs markdown table --anchor=false --hide-empty .
## Requirements

| Name | Version |
|------|---------|
| terraform | >= 1.2.6 |
| azurerm | 3.15.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| tfc-agents-aci | ../.. | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| agent\_image | The registry/image:tag\_Version to use for the agent. Default = hashicorp/tfc-agent:latest | `string` | `"hashicorp/tfc-agent:latest"` | no |
| agent\_log\_level | The log verbosity. Level options include 'trace', 'debug', 'info', 'warn', and 'error'. Log levels have a progressive level of data sensitivy. The 'info', 'warn', and 'error' levels are considered generally safe for log collection and don't include sensitive information. The 'debug' log level may include internal system details, such as specific commands and arguments including paths to user data on the local filesystem. The 'trace' log level is the most sensitive and may include personally identifiable information, secrets, pre-authorized internal URLs, and other sensitive material. | `string` | `"info"` | no |
| common\_tags | Map of common tags for taggable AWS resources. | `map(string)` | `{}` | no |
| cpu | Number of cpu units used by the container. | `string` | `"1.0"` | no |
| location | The location of the resources. | `string` | `"East US"` | no |
| log\_analytics\_workspace\_retention | The number of days to retain logs. | `number` | `"30"` | no |
| make\_private | The option to use private IP addresses over public IP addresses. | `bool` | `true` | no |
| memory | Amount of memory used by the container. | `string` | `"2.0"` | no |
| private\_subnet\_id | The ID of the private delegated subnet to place the container into. Only used when `make_private` set to true. | `string` | `""` | no |
| resource\_group\_name | The name of an existing resource group | `string` | n/a | yes |
| tfc\_address | Hostname of self-hosted TFE instance. Leave default if TFC is in use. | `string` | `"https://app.terraform.io"` | no |
| tfc\_agent\_name | The name of the agent. | `string` | `"tfc-agent"` | no |
| tfc\_agent\_token | Agent pool token to authenticate to TFC/TFE when cloud agents are instantiated. | `string` | n/a | yes |