# terraform-azurerm-tfc-agents-aci
A module to deploy Terraform Cloud Agents on Azure Container Instances.

## Requirments
### External Agents - Azure Assigned Public IP
- An Existing Resource Group
### Internal Agents - Custom VNET, Subnet, and IP Addressing
The following must exist in your Azure Subscription
- An Existing Resource Group
- An Existing VNET
- An Existing Subnet with delegation 'Microsoft.ContainerInstance'
- An Existing NAT Gateway inside the subnet if private.
- Any Network Security Groups must allow egress to Terraform Cloud.

## Using This Module
There is an `examples` folder in this directory that contains different scenarios. The `external-agents` example deploys onto Azure controlled infrastructure. The agent will be given a public IP address. The `internal-agents` example allows you to specify an existing VNET and subnet to allow you to place the agent in a private or public subnet.

Choose the example you want to use and edit the `terraform.tfvars.example` file with your values, and rename it to `terraform.tfvars`. See the README for each example for more information.

## A Note on Using Public Ip Addressing
If you use the `external-agents` example, you do not provide your own VNET. The underlying Azure infrastructure will be used. This will be an issue if you are controlling access to Azure resources such as Storage Accounts via whitelists. The public IP of this infrastructure is not exposed, so there is no way to whitelist the agent in this scenario to allow it to manage the resource. If you wish to expose the agent in a public subnet, you can do that using the private example, and pass in the subnet ID of a public subnet instead of a private one.

## Providers

## Requirements

| Name | Version |
|------|---------|
| terraform | >= 1.2.6 |
| azurerm | 3.15.0 |

## Resources

| Name | Type |
|------|------|
| [azurerm_container_group.tfc-agent](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/container_group) | resource |
| [azurerm_log_analytics_workspace.logging](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/log_analytics_workspace) | resource |
| [azurerm_network_profile.tfc](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_profile) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| agent\_image | The registry/image:tag\_Version to use for the agent. Default = hashicorp/tfc-agent:latest | `string` | `"hashicorp/tfc-agent:latest"` | no |
| agent\_log\_level | The log verbosity. Level options include 'trace', 'debug', 'info', 'warn', and 'error'. Log levels have a progressive level of data sensitivy. The 'info', 'warn', and 'error' levels are considered generally safe for log collection and don't include sensitive information. The 'debug' log level may include internal system details, such as specific commands and arguments including paths to user data on the local filesystem. The 'trace' log level is the most sensitive and may include personally identifiable information, secrets, pre-authorized internal URLs, and other sensitive material. | `string` | `"info"` | no |
| common\_tags | Map of common tags for taggable AWS resources. | `map(string)` | `{}` | no |
| cpu | Number of cpu units used by the container. | `string` | `"1.0"` | no |
| location | The location of the resources. | `string` | `"East US"` | no |
| log\_analytics\_workspace\_retention | The number of days to retain logs. | `number` | `"30"` | no |
| make\_private | The option to use private IP addresses over public IP addresses. | `bool` | `true` | no |
| memory | Amount of memory used by the container. | `string` | `"2.0"` | no |
| private\_subnet\_id | The ID of the private delegated subnet to place the container into. Only used when `make_private` set to true. | `string` | `""` | no |
| resource\_group\_name | The name of an existing resource group | `string` | n/a | yes |
| tfc\_address | Hostname of self-hosted TFE instance. Leave default if TFC is in use. | `string` | `"https://app.terraform.io"` | no |
| tfc\_agent\_name | The name of the agent. | `string` | `"tfc-agent"` | no |
| tfc\_agent\_token | Agent pool token to authenticate to TFC/TFE when cloud agents are instantiated. | `string` | n/a | yes |